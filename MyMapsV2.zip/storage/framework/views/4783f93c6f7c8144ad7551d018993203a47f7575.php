<div class="box box-info padding-1">
    <div class="box-body">
        <div class="form-group">
            <?php echo e(Form::label('Codigo')); ?>

            <?php echo e(Form::text('codigo', $finca->codigo, ['class' => 'form-control' . ($errors->has('codigo') ? ' is-invalid' : ''), 'placeholder' => 'Codigo'])); ?>

            <?php echo $errors->first('codigo', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Nombre')); ?>

            <?php echo e(Form::text('nombre', $finca->nombre, ['class' => 'form-control' . ($errors->has('nombre') ? ' is-invalid' : ''), 'placeholder' => 'Nombre'])); ?>

            <?php echo $errors->first('nombre', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Descripcion')); ?>

            <?php echo e(Form::text('administracion', $finca->administracion, ['class' => 'form-control' . ($errors->has('administracion') ? ' is-invalid' : ''), 'placeholder' => 'Administracion'])); ?>

            <?php echo $errors->first('administracion', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Id Ruta')); ?>

            <?php echo e(Form::text('idruta', $finca->idruta, ['class' => 'form-control' . ($errors->has('idruta') ? ' is-invalid' : ''), 'placeholder' => 'Id Ruta'])); ?>

            <?php echo $errors->first('idruta', '<div class="invalid-feedback">:message</p>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Guardar</button>
    </div>
</div><?php /**PATH C:\wamp64\www\UMG\MyMapsV2\resources\views/finca/form.blade.php ENDPATH**/ ?>