<?php $__env->startSection('template_title'); ?>
    <?php echo e($confirmacione->name ?? 'Show Confirmacione'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Ver Confirmaciones</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('confirmaciones.index')); ?>"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Idprogramado:</strong>
                            <?php echo e($confirmacione->idprogramado); ?>

                        </div>
                        <div class="form-group">
                            <strong>Latitud:</strong>
                            <?php echo e($confirmacione->latitud); ?>

                        </div>
                        <div class="form-group">
                            <strong>Longitud:</strong>
                            <?php echo e($confirmacione->longitud); ?>

                        </div>
                        <div class="form-group">
                            <strong>Abastecida:</strong>
                            <?php echo e($confirmacione->abastecida); ?>

                        </div>
                        <div class="form-group">
                            <strong>Descripcion:</strong>
                            <?php echo e($confirmacione->descripcion); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\UMG\MyMapsV2\resources\views/confirmacione/show.blade.php ENDPATH**/ ?>