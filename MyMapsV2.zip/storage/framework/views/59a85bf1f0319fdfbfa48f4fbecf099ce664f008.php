<?php $__env->startSection('template_title'); ?>
    <?php echo e($finca->name ?? 'Show Finca'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Datos de la Finca</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('fincas.index')); ?>"> Retornar</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>id:</strong>
                            <?php echo e($finca->id); ?>

                        </div>
                        <div class="form-group">
                            <strong>Codigo:</strong>
                            <?php echo e($finca->codigo); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nombre:</strong>
                            <?php echo e($finca->nombre); ?>

                        </div>
                        <div class="form-group">
                            <strong>Idruta:</strong>
                            <?php echo e($finca->idruta); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\UMG\MyMapsV2\resources\views/finca/show.blade.php ENDPATH**/ ?>